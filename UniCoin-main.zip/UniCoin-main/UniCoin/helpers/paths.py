PATH_DATA = 'data'
PATH_WALLETS = f'{PATH_DATA}/wallets'

FILE_NODELIST = f'{PATH_DATA}/node_list.json'
