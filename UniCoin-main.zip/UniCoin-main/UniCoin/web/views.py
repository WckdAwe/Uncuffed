# from flask import render_template, redirect, request
# from UniCoin import app
#
#
# @app.route('/')
# def index():
# 	return render_template('index.html',
# 						   page_title='&bull; Index')
