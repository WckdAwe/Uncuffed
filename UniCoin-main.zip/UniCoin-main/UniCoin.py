import UniCoin

if __name__ == '__main__':
	port = int(input('Port: '))
	UniCoin.run(port)
	# UniCoin.tst_run(port)
